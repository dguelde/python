import csv
import re

def main():
  filename = 'edgar_allan_poe_thecastofamontillado'
  author = 'edgar_allan_poe'
  header = 'Produced by'
  footer = 'End of'

  f = open('raw_data/%s.txt' % filename, 'r')
  data = f.read()
  f.close()

  # Get everything after the header
  data = data.partition(header)[2]

  # Get everything before the footer
  data = data.partition(footer)[0]

  # Create a list out of the lines in the file.
  data = data.split('\n')

  # Remove who produced the project gutenberg work.
  del data[0]

  # Remove everything from each of the lines except for spaces and words.
  # data = [KeepWordsSpaces(line) for line in data]

  # Remove any leading whitespace characters and spaces from each line.
  data = [line.lstrip() for line in data]
  # Remove any trailing whitespace characters and spaces from each line.
  data = [line.rstrip() for line in data]

  # Write out each line to a csv file with column 1 being the author name
  # and column 2 being the sentence.
  with open('csv_data/%s.csv' % filename, 'w') as csvfile:
    writer = csv.writer(csvfile)
    for line in data:
      # If the line is not an empty string.
      if line:
        writer.writerow([author, line])

if __name__ == '__main__':
  main()


